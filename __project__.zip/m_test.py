from PIL import Image
import os
import numpy as np
import tensorflow as tf
from keras import layers, models

# 각 연산별 데이터셋 폴더 경로
plus_dataset_path = "plus"
minus_dataset_path = "minus"
divide_dataset_path = "divide"
hat_dataset_path="hat"
multiply_dataset_path="multiply"
variableX_dataset_path = "variableX"

# 데이터셋 로드 및 전처리 함수
def load_and_preprocess_dataset(dataset_path):
    images = []
    labels = []

    for filename in os.listdir(dataset_path):
        if filename.endswith(".png"):
            img_path = os.path.join(dataset_path, filename)
            image = Image.open(img_path).convert("L")
            image = image.resize((28, 28))
            image_array = np.array(image).reshape((28, 28, 1)).astype("float32") / 255.0
            label = int(filename.split("_")[0])  # 파일명에서 문자 추룰

            images.append(image_array)
            labels.append(label)

    num_classes = np.max(labels) + 1
    return np.array(images), tf.keras.utils.to_categorical(labels, num_classes=num_classes), num_classes

# 각 연산에 대한 데이터셋 로드 및 전처리
plus_images, plus_labels, num_classes_plus = load_and_preprocess_dataset(plus_dataset_path)
minus_images, minus_labels, num_classes_minus = load_and_preprocess_dataset(minus_dataset_path)
divide_images, divide_labels, num_classes_divide = load_and_preprocess_dataset(divide_dataset_path)
hat_images,hat_labels,num_classes_hat=load_and_preprocess_dataset(hat_dataset_path)
multiply_images,multiply_labels,num_classes_multiply=load_and_preprocess_dataset(multiply_dataset_path)
variableX_images,variableX_labels,num_classes_variableX=load_and_preprocess_dataset(variableX_dataset_path)

# 각각의 모델 구성
def create_model(input_shape, num_classes):
    model = models.Sequential()
    model.add(layers.Conv2D(32, (3, 3), activation="relu", input_shape=input_shape))
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.Conv2D(64, (3, 3), activation="relu"))
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.Conv2D(64, (3, 3), activation="relu"))
    model.add(layers.Flatten())
    model.add(layers.Dense(64, activation="relu"))
    model.add(layers.Dense(num_classes, activation="softmax"))
    model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
    return model

# 각각의 모델 생성
plus_model = create_model((28, 28, 1), num_classes_plus)
minus_model = create_model((28, 28, 1), num_classes_minus)
divide_model = create_model((28, 28, 1), num_classes_divide)
hat_model=create_model((28,28,1),num_classes_hat)
multiply_model=create_model((28,28,1),num_classes_multiply)
variableX_model=create_model((28,28,1),num_classes_variableX)

# 각 모델 훈련
plus_model.fit(plus_images, plus_labels, epochs=10, batch_size=256, validation_split=0.2)
minus_model.fit(minus_images, minus_labels, epochs=10, batch_size=256, validation_split=0.2)
divide_model.fit(divide_images, divide_labels, epochs=10, batch_size=256, validation_split=0.2)
hat_model.fit(hat_images, hat_labels, epochs=10, batch_size=256, validation_split=0.2)
multiply_model.fit(multiply_images, multiply_labels, epochs=10, batch_size=256, validation_split=0.2)
variableX_model.fit(variableX_images, variableX_labels, epochs=10, batch_size=256, validation_split=0.2)

# 각 모델의 출력 레이어를 제외한 부분을 가져와서 합칠 모델 생성
combined_model = models.Sequential()
combined_model.add(layers.Conv2D(32, (3, 3), activation="relu", input_shape=(28, 28, 1)))
combined_model.add(layers.MaxPooling2D((2, 2)))
combined_model.add(layers.Conv2D(64, (3, 3), activation="relu"))
combined_model.add(layers.MaxPooling2D((2, 2)))
combined_model.add(layers.Conv2D(64, (3, 3), activation="relu"))
combined_model.add(layers.Flatten())
combined_model.add(layers.Dense(64, activation="relu"))

# 추가한 부분: 각 모델의 출력 레이어를 제외한 부분을 추가
combined_model.add(plus_model.layers[-3])
combined_model.add(minus_model.layers[-3])
combined_model.add(divide_model.layers[-3])
combined_model.add(hat_model.layers[-3])
combined_model.add(multiply_model.layers[-3])
combined_model.add(variableX_model.layers[-3])


combined_model.add(layers.Dense(32,activation="relu"))
combined_model.add(layers.Dense(3, activation="softmax"))  # 최종 출력 레이어, 클래스 개수는 연산 종류의 수 (덧셈, 뺄셈, 나눗셈)

combined_model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])

# 훈련된 모델 저장
combined_model.save("combined_model.h5")

#variableX는 22~25가 앞에꺼랑 동일
